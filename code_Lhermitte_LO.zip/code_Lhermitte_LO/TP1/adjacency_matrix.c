#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>//to estimate the runing time

#define NLINKS 100000000 //maximum number of edges for memory allocation, will increase if needed
typedef struct {
	unsigned long s;
	unsigned long t;
} edge;

//edge list structure:
typedef struct {
	unsigned long n;//number of nodes
	unsigned long e;//number of edges
	edge *edges;//list of edges
} edgelist;

//edge list structure:
typedef struct {
	unsigned long n;//number of nodes
	unsigned long e;//number of edges
	bool *mat;//adjacency matrix with 1 or 0
	// We note that it's not a squared matrix but a list per say. That allows us to write less 0 (memory usage) since the matrices can be very sparse
} adj_mat;

//compute the maximum of three unsigned long
inline unsigned long max3(unsigned long a,unsigned long b,unsigned long c){
	a=(a>b) ? a : b;
	return (a>c) ? a : c;
}
//reading the edgelist from file
edgelist* readedgelist(char* input){
	unsigned long e1=NLINKS;
	edgelist *g=malloc(sizeof(edgelist));
	FILE *file;
	g->n=0;
	g->e=0;
	file=fopen(input,"r");
	g->edges=malloc(e1*sizeof(edge));
	while (fscanf(file,"%lu %lu", &(g->edges[g->e].s), &(g->edges[g->e].t))==2) {
		g->n=max3(g->n,g->edges[g->e].s,g->edges[g->e].t);
		if (g->e++==e1) {
			e1+=NLINKS;
			g->edges=realloc(g->edges,e1*sizeof(edge));
		}
	}
	fclose(file);
	g->n++;
	g->edges=realloc(g->edges,g->e*sizeof(edge));
	return g;
}

void free_edgelist(edgelist *g){
	free(g->edges);
	free(g);
}

//Represent the graph with its adjacency matrix
adj_mat* adjacency_matrix(edgelist* g){
	adj_mat *a=malloc(sizeof(adj_mat));
	unsigned long i,j,k;
	a->mat=calloc(g->n*g->n,sizeof(bool)); // bool because the adjacency matrix is binary
	for (i=0;i<g->e;i++){
		j=g->edges[i].s;
		k=g->edges[i].t;
		a->mat[j+g->n*k]=1;
		a->mat[k+g->n*j]=1;
		
	a->n = g->n;
	a->e = g->e;
	return a;
	}
}

void free_adj_mat(adj_mat *g){
	free(g->mat);
	free(g);
}

int main(int argc,char** argv){
	edgelist *g;
	adj_mat* a;
	time_t t1,t2;

	t1=time(NULL);

	printf("Reading edgelist from file %s\n",argv[1]);
	g=readedgelist(argv[1]);

	printf("Number of nodes: %lu\n",g->n);
	printf("Number of edges: %lu\n",g->e);

	printf("Building the adjacency matrix\n");
	a = adjacency_matrix(g);
	printf("Number of nodes: %lu\n",a->n);
	unsigned i;
	/*
	for(i=0;i<a->n;i++){
		printf("Number of edges: %u\n",a->mat[i]);}*/
	free_adj_mat(a);
	free_edgelist(g);
	t2=time(NULL);

	printf("- Overall time = %ldh%ldm%lds\n",(t2-t1)/3600,((t2-t1)%3600)/60,((t2-t1)%60));

	return 0;
}


