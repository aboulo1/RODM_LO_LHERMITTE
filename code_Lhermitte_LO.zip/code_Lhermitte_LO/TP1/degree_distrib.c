#include <stdlib.h>
#include <stdio.h>
#include <time.h>//to estimate the runing time

#define NLINKS 100000000

// exercise 2 : size of graph
void countnodesedges(char* input){
	unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");

	unsigned long maxnode=0;
    unsigned long i=0;
    
    unsigned long s;
    unsigned long t;
    while (fscanf(file,"%lu %lu", &s, &t)==2) {
        i++;
        if (s>maxnode){maxnode=s;}
        if (t>maxnode){maxnode=t;}
	}        
	fclose(file);
    
    printf("number of nodes : %lu \n",maxnode);
    printf("number of eges : %lu \n",i);

}

unsigned long countnodes(char* input){
	unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");

	unsigned long maxnode=0;
    
    unsigned long s;
    unsigned long t;
    while (fscanf(file,"%lu %lu", &s, &t)==2) {
        if (s>maxnode){maxnode=s;}
        if (t>maxnode){maxnode=t;}
	}        
	fclose(file);
    
    return maxnode;

}

unsigned long countedges(char* input){
	unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");

	unsigned long i=0;
    
    unsigned long s;
    unsigned long t;
    while (fscanf(file,"%lu %lu", &s, &t)==2) {
        i++;
	}        
	fclose(file);
    
    return i;

}

// exercise 4 : compute node degrees

void nodedegrees1(char* input){
	unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");
    
    unsigned long number_of_nodes = countnodes(input);
    int *degrees = calloc(number_of_nodes,sizeof(int));
    
    unsigned long s;
    unsigned long t;
    while (fscanf(file,"%lu %lu", &s, &t)==2) {
        if (s!=t){
            degrees[s]++;
            degrees[t]++;
        }
        else{
            degrees[s]++;
        }
        	
	}        
	fclose(file);

    FILE *wfile=fopen("email_degrees.txt","w");
    
    int compteur;
    for (compteur=0;compteur<number_of_nodes;compteur++){
        fprintf(wfile,"%u %u \n",compteur,degrees[compteur]);
    }
    fclose(wfile);
    
}

unsigned long* nodedegrees(char* input){
	unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");
    
    unsigned long number_of_nodes = countnodes(input);
    unsigned long *degrees = calloc(number_of_nodes,sizeof(unsigned long));
    
    unsigned long s;
    unsigned long t;
    while (fscanf(file,"%lu %lu", &s, &t)==2) {
        if (s!=t){
            degrees[s]++;
            degrees[t]++;
        }
        else{
            degrees[s]++;
        }
        	
	}        
	fclose(file);

    return degrees;
    
}

// exercise 5 : compute special quantity
unsigned long specialquantity(char* input){

    unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");
    
    unsigned long* degrees = nodedegrees(input);
    unsigned long q=0;
    
    unsigned long s;
    unsigned long t;
    while (fscanf(file,"%lu %lu", &s, &t)==2) {
        q = q + degrees[s]*degrees[t];
        q = q+1;
    }
    return q;
}

// exercise 6 : degree distribution
void degreedistribution(char* input){

    // list of degrees
    unsigned long* degrees = nodedegrees(input);
    
    // number of nodes
    unsigned long nbnodes = countnodes(input);

    // max of degrees
    unsigned long max_degree = 0;
    unsigned long compteur;
    for(compteur=0;compteur<nbnodes;compteur++){
        if (max_degree<degrees[compteur]){
            max_degree = degrees[compteur];
        }
    }

    unsigned long* degreedstrb = calloc(max_degree,sizeof(unsigned long));

    for(compteur=0;compteur<nbnodes;compteur++){
        degreedstrb[degrees[compteur]]++;
    }

    // write the result in the file
    FILE *wfile=fopen("degree_distribution.txt","w");
    
    for (compteur=0;compteur<max_degree;compteur++){

        if(degreedstrb[compteur]>0){
            fprintf(wfile,"%lu %lu \n",compteur,degreedstrb[compteur]);
        }

    }
    fclose(wfile);

}

int main(int argc,char** argv){
	FILE* file;
	time_t t1,t2;

	t1=time(NULL);
	printf("Reading edgelist from file %s\n",argv[1]);
	degreedistribution(argv[1]);
	t2=time(NULL);
	printf("- Overall time = %ldh%ldm%lds\n",(t2-t1)/3600,((t2-t1)%3600)/60,((t2-t1)%60));
	}
