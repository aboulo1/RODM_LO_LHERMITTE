#include <stdlib.h>
#include <stdio.h>
#include <time.h>//to estimate the runing time
#include <stdbool.h>

#define NLINKS 100000000 //maximum number of edges for memory allocation, will increase if needed
//This script is to compute the number of triangles in a graph. It gets more  accurate when the graph is bigger.
//typedef enum {false,true} bool;
typedef struct {
	unsigned long s;
	unsigned long t;
} edge;


//edge list structure:
typedef struct {
	unsigned long n;//number of nodes
	unsigned long e;//number of edges
	edge *edges;//list of edges
} edgelist;

//edge list structure:
typedef struct {
	unsigned long n;
	unsigned long e;
	unsigned long *cd;//cumulative degree 
	unsigned long *adj;// adjacency list
} adj_arr;

//compute the maximum of three unsigned long
inline unsigned long max3(unsigned long a,unsigned long b,unsigned long c){
	a=(a>b) ? a : b;
	return (a>c) ? a : c;
}
//reading the edgelist from file
edgelist* readedgelist(char* input){
	unsigned long e1=NLINKS;
	edgelist *g=malloc(sizeof(edgelist));
	FILE *file;

	g->n=0;
	g->e=0;
	file=fopen(input,"r");
	g->edges=malloc(e1*sizeof(edge));
	while (fscanf(file,"%lu %lu", &(g->edges[g->e].s), &(g->edges[g->e].t))==2) {
		g->n=max3(g->n,g->edges[g->e].s,g->edges[g->e].t);
		if (g->e++==e1) {
			e1+=NLINKS;
			g->edges=realloc(g->edges,e1*sizeof(edge));
		}
	}
	fclose(file);
	g->n++;

	g->edges=realloc(g->edges,g->e*sizeof(edge));

	return g;
}

void free_edgelist(edgelist *g){
	free(g->edges);
	free(g);
}

//Represent the graph with its adjacency array
adj_arr* adjacency_array(edgelist* g){
	adj_arr *a=malloc(sizeof(adj_arr));
	unsigned long i,j,k;
	unsigned long *deg=calloc(g->n,sizeof(unsigned long));

	for (i=0;i<g->e;i++) {
		deg[g->edges[i].s]++;
		deg[g->edges[i].t]++;
	}

	unsigned long *deg_untilnow = calloc(g->n,sizeof(unsigned long));

	a->cd=malloc((g->n+1)*sizeof(unsigned long));
	a->cd[0]=0;
	for (i=0; i<g->n; i++) {
		a->cd[i+1]=a->cd[i]+deg[i];
	}
	a->adj=malloc(2*g->e*sizeof(unsigned long));

	for (i=0; i<g->e; i++) {
		j=g->edges[i].s;
		k=g->edges[i].t;
		deg_untilnow[j]++;
		a->adj[a->cd[j] + deg_untilnow[j]-1]=k;
		deg_untilnow[k]++;
		a->adj[a->cd[k] + deg_untilnow[k]-1]=j;
	}

	free(deg);
	free(deg_untilnow);
	a->n = g->n;
	a->e = g->e;
	return a;
}


unsigned long tr_count(adj_arr* g){
  adj_arr* gtr=g;
  bool *trgl=calloc(gtr->n,sizeof(bool));
  unsigned long tr=0;
  unsigned i,j,tr1,tr2,tr3;
  for (tr1=0;tr1<gtr->n;tr1++){
    for (i=gtr->cd[tr1] ;i<gtr->cd[tr1+1] ;i++){
      trgl[gtr->adj[i]]=1;
    }
    for (i=gtr->cd[tr1];i<gtr->cd[tr1+1];i++){
      tr2=gtr->adj[i];
      for (j=gtr->cd[tr2];j<gtr->cd[tr2+1];j++){
        tr3=gtr->adj[j];
        if (trgl[tr3]==1){
          tr++;
        }
      }
    }
    for (i=gtr->cd[tr1];i<gtr->cd[tr1+1];i++){
      trgl[gtr->adj[i]]=0;
    }
  }
  free(trgl);
  return tr/6;
}

void free_adj_arr(adj_arr *g){
	free(g->cd);
	free(g->adj);
	free(g);
}


int main(int argc,char** argv){
	adj_arr* a;
	edgelist *g;
	time_t t1,t2;

	t1=time(NULL);

	printf("Reading edgelist from file %s\n",argv[1]);
	g=readedgelist(argv[1]);
	a = adjacency_array(g);
	printf("Number of nodes: %lu\n",g->n);
	printf("Number of edges: %lu\n",g->e);

	printf("Building the adjacency matrix\n");
	unsigned long count = tr_count(a);
	printf("%ld",count);
	free_adj_arr(a);
	free_edgelist(g);
	t2=time(NULL);

	printf("- Overall time = %ldh%ldm%lds\n",(t2-t1)/3600,((t2-t1)%3600)/60,((t2-t1)%60));

	return 0;
}
