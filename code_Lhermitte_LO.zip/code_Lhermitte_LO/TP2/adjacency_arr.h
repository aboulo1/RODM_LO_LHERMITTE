#ifndef ADJACENCY_ARR_H_INCLUDED
#define ADJACENCY_ARR_H_INCLUDED


#include <stdlib.h>
#include <stdio.h>
#include <time.h>//to estimate the runing time

#define NLINKS 100000000 //maximum number of edges for memory allocation, will increase if needed

typedef struct {
	unsigned long s;
	unsigned long t;
} edge;


//edge list structure:
typedef struct {
	unsigned long n;//number of nodes
	unsigned long e;//number of edges
	edge *edges;//list of edges
} edgelist;

//edge list structure:
typedef struct {
	unsigned long n;
	unsigned long e;
	unsigned long *cd;//cumulative degree 
	unsigned long *adj;// adjacency list
} adj_arr;

//compute the maximum of three unsigned long
inline unsigned long max3(unsigned long a,unsigned long b,unsigned long c){
	a=(a>b) ? a : b;
	return (a>c) ? a : c;
}
//reading the edgelist from file
edgelist* readedgelist(char* input);

void free_edgelist(edgelist *g);

//Represent the graph with its adjacency array
adj_arr* adjacency_array(edgelist* g);

void free_adj_arr(adj_arr *g);

#endif
