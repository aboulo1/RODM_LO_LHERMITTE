#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "adjacency_arr.h"

typedef struct {
	unsigned long *corevalues; // kcore values of nodes
	unsigned long *ordering; // kcore ordering
} kcoredecomposition;

kcoredecomposition* kcore(adj_arr *g){
    kcoredecomposition *kcores = malloc(sizeof(kcoredecomposition));
    kcores->corevalues = malloc(g->n*sizeof(unsigned long));
    kcores->ordering = malloc(g->n*sizeof(unsigned long));

    // on calcule le degré
    unsigned long deg[g->n];

    unsigned long i;
    for (i=0;i<g->n;i++){
        deg[i] = g->cd[i+1]-g->cd[i];
    }

    // initialize already visited
    unsigned long alreadyvisited[g->n];
    unsigned long l;
    for(l=0;l<g->n;l++){
        alreadyvisited[l]=0;
    }

    // initialize core value
    unsigned long corevalue=0;
    unsigned long ordering=g->n-1;

    // we can start ; normally it's a while but we know the length of the while
    for(i=0;i<g->n;i++){

        // on trouve le degre min
        unsigned long mindegree = g->n;
        unsigned long l;
        for(l=0;l<g->n;l++){
            if(deg[l]<mindegree){mindegree=deg[l];}
        }
        unsigned long mindegreenode = 0;

        unsigned long exitcondition = 1;
        l=0;
        while (exitcondition>0){
            if(deg[l]==mindegree){
                mindegreenode=l;
                exitcondition=0;
            }
            l++;
        }

        // on marque mindegreenode
        alreadyvisited[mindegreenode] = 1;

        // on récupère les voisins de mindegreenode
        unsigned long initialdegree = g->cd[mindegreenode+1]-g->cd[mindegreenode];
        unsigned long neighbors[initialdegree];
        for(l=0;l<initialdegree;l++){
            neighbors[l] = g->adj[g->cd[mindegreenode]+l]; 
        }

        // on diminue le degré de tous ces voisins (si ils sont encore considérés)
        for(l=0;l<initialdegree;l++){
            if(alreadyvisited[neighbors[l]]==0){deg[neighbors[l]]--;}
        }

        //on met également à jour la corevalue
        if(mindegree>corevalue){corevalue=mindegree;}

        // on stocke la valeur de corevalue dans le resulat
        kcores->corevalues[mindegreenode] = corevalue;

        // on stocke également le kcore ordering
        kcores->ordering[mindegreenode] = ordering;
        ordering--;

        // pour ne pas avoir de problèmes
        deg[mindegreenode] = g->n+1;

    }

    return kcores;
}

void free_kcoredecomposition(kcoredecomposition *kcore){
    free(kcore->corevalues);
    free(kcore->ordering);
    free(kcore);
}

int main(int argc,char** argv){
    
	time_t t1,t2;

	t1=time(NULL);

	printf("Reading edgelist from file %s\n",argv[1]);
    edgelist *edges;
	edges=readedgelist(argv[1]);

    printf("Building the adjacency array\n");
    adj_arr* g;
    g = adjacency_array(edges);

	printf("Number of nodes: %lu\n",g->n);
	printf("Number of edges: %lu\n",g->e);

    // kcoredecomposition
    printf("computing kcoredecomposition\n");
    kcoredecomposition *kcoreresults = kcore(g);
    
    /*
    printf("printing kcorevalues and kcore ordering\n");
    unsigned long j;
    for(j=0;j<g->n;j++){
        printf("%lu %lu %lu\n",j, kcoreresults->ordering[j],kcoreresults->corevalues[j]);
    }*/

    printf("core value : %lu\n", kcoreresults->corevalues[kcoreresults->ordering[0]]);
    
    free_kcoredecomposition(kcoreresults);

    free_edgelist(edges);
    free_adj_arr(g);

	t2=time(NULL);

	printf("- Overall time = %ldh%ldm%lds\n",(t2-t1)/3600,((t2-t1)%3600)/60,((t2-t1)%60));

	return 0;
}
