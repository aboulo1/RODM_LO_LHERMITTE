
#include <stdlib.h>
#include <stdio.h>
#include <time.h>//to estimate the runing time

#define NLINKS 100000000 //maximum number of edges for memory allocation, will increase if needed

typedef struct {
	unsigned long s;
	unsigned long t;
} edge;

//edge list structure:
typedef struct {
	unsigned long n;//number of nodes
	unsigned long e;//number of edges
	edge *edges;//list of edges
} edgelist;

//compute the maximum of three unsigned long
inline unsigned long max3(unsigned long a,unsigned long b,unsigned long c){
	a=(a>b) ? a : b;
	return (a>c) ? a : c;
}

//reading the edgelist from file
edgelist* readedgelist(char* input){
	unsigned long e1=NLINKS;
	FILE *file=fopen(input,"r");

	edgelist *g=malloc(sizeof(edgelist));
	g->n=0;
	g->e=0;
	g->edges=malloc(e1*sizeof(edge));//allocate some RAM to store edges

	while (fscanf(file,"%lu %lu", &(g->edges[g->e].s), &(g->edges[g->e].t))==2) {
		g->n=max3(g->n,g->edges[g->e].s,g->edges[g->e].t);
		if (g->e++==e1) {//increase allocated RAM if needed
			e1+=NLINKS;
			g->edges=realloc(g->edges,e1*sizeof(edge));
		}
	}
	fclose(file);

	g->n++;

	g->edges=realloc(g->edges,g->e*sizeof(edge));

	return g;
}

void free_edgelist(edgelist *g){
	free(g->edges);
	free(g);
}


// function to compute degrees of each node
unsigned long* nodedegreesout(edgelist* listofedges){

    // initialize result
    unsigned long *degreesout = calloc(listofedges->n,sizeof(unsigned long));

    // loop over the list of edges
    unsigned long compteur = 0 ;
    for(compteur=0;compteur<listofedges->e;compteur++){
        degreesout[listofedges->edges[compteur].s]++;
    }

    return degreesout;
    
}

unsigned long* nodedegreesin(edgelist* listofedges){

    // initialize result
    unsigned long *degreesin = calloc(listofedges->n,sizeof(unsigned long));

    // loop over the list of edges
    unsigned long compteur = 0 ;
    for(compteur=0;compteur<listofedges->e;compteur++){
        degreesin[listofedges->edges[compteur].t]++;
    }

    return degreesin;
    
}

double* pagerank(char* input,float alpha,int K){

	//list of edges
	edgelist* listofedges = readedgelist(input);

    // list of degrees
    unsigned long* degreesout = nodedegreesout(listofedges);

    // initialize result
    double* Pt = calloc(listofedges->n,sizeof(double));
	double* Ptp1 = calloc(listofedges->n,sizeof(double));
	// on met tous les termes de Pt à 1/n
	unsigned long i;
	for (i=1;i<listofedges->n;i++){
		Pt[i]=1/listofedges->n;
	}

    int k;
    for(k=0;k<K;k++){

        // on fait le produit matriciel Pt <-T*Ptm1
		// en itérant sur tous les liens

		// on commence par remettre à 0 Ptp1
		for (i=1;i<listofedges->n;i++){
			Ptp1[i]=0;
		}

		// on fait le produit matriciel
        unsigned long compteur = 0;
        for(compteur=0;compteur<listofedges->e;compteur++){
            edge currentedge = listofedges->edges[compteur];
            Ptp1[currentedge.t] = Ptp1[currentedge.t] + Pt[currentedge.s]/degreesout[currentedge.s];
        }

		// on fait la CL et on calcule la norme
        double norm1P = 0;
        for(compteur=0;compteur<listofedges->n;compteur++){
            Ptp1[compteur] = (1-alpha)*Ptp1[compteur]+alpha/listofedges->n;
            norm1P = norm1P + abs(Ptp1[compteur]);
        }

        // normalization "2"
        for(compteur=0;compteur<listofedges->n;compteur++){
            Ptp1[compteur] = Ptp1[compteur]+(1-norm1P)/listofedges->n;
        }

		// on met à jour Pt
		for (i=1;i<listofedges->n;i++){
			Pt[i]=Ptp1[i];
		}
    }

    free_edgelist(listofedges);
	free(degreesout);
	free(Ptp1);

    return Pt;

}

// on veut trier avec qsort
// attention il faut retracer les index ; il faut donc définir une structure contenant la valeur
// et l'index et définir une fonction de comparaison qui ne prend en compte que les valeurs
typedef struct{
	unsigned long pageid;
	double score;
} pagescore;

int compare(const void* p1, const void* p2)
{
    return ((*(pagescore*)p2).score < (*(pagescore*)p1).score) ? -1 : +1;
}

int main(int argc,char** argv){
	edgelist* g;
	time_t t1,t2;

	t1=time(NULL);

	printf("Reading edgelist from file %s\n",argv[1]);
	g=readedgelist(argv[1]);

	printf("Number of nodes: %lu\n",g->n);
	printf("Number of edges: %lu\n",g->e);

	printf("Computing PageRank\n");
	double* pr = pagerank(argv[1],0.9,30);

	printf("Sorting PageRank\n");
	pagescore *p=malloc(g->n*sizeof(pagescore));
	unsigned long i;
	for (i=0;i<g->n;i++){
		p[i].pageid=i;
		p[i].score=pr[i];
	}

	//qsort(p,g->n,sizeof(pagescore),compare);

    /*
	printf("Top 5 pages :\n");
	for (i=0;i<5;i++){
		printf("rank %d : pageid=%ld ; score=%f\n", i, p[i].pageid, p[i].score);
	}*/

    //write results
    /*
    FILE* file = fopen("pagerank_wiki_090.txt","w");

    for (i=0;i<g->n;i++){
        unsigned long id = p[i].pageid;
        double score = p[i].score;
        fprintf(file,"%lu %lf\n",id,score);
    }

    fclose(file);*/


    //code pour écrire degreesout et degreesin dans un fichier
    
    unsigned long* degreesout = nodedegreesout(g);
    unsigned long* degreesin = nodedegreesin(g);
    
    FILE* filedegout = fopen("degreesout_wiki.txt","w");
    FILE* filedegin = fopen("degreesin_wiki.txt","w");

    for (i=0;i<g->n;i++){
        fprintf(filedegout,"%lu %lu\n",i,degreesout[i]);
        fprintf(filedegin,"%lu %lu\n",i,degreesin[i]);
    }

    fclose(filedegout);
    fclose(filedegin);

    free(degreesout);
    free(degreesin);


	// il ne faut pas oublier de libérer les variables
    // par exemple free(Pt);
	free_edgelist(g);
	free(pr);
	free(p);

	t2=time(NULL);

	printf("- Overall time = %ldh%ldm%lds\n",(t2-t1)/3600,((t2-t1)%3600)/60,((t2-t1)%60));

	return 0;
}


