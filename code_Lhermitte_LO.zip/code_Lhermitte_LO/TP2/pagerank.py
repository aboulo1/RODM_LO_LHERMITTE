
# print top5 and last5
with open("pagerank_wiki_015_sorted.txt") as f :
    pagerank = [line.strip() for line in f]

pagerank = [line.split(" ") for line in pagerank]
pagerank = [[int(line[0]),float(line[1])] for line in pagerank]

with open("pageNum2Name.txt") as f:
    num2name = [line.strip() for line in f]
num2name = [line.split(" ") for line in num2name]
num2name = [line[1] for line in num2name]

top5 = pagerank[0:5]
last5 = pagerank[-5:]

print("top 5 :")
for page in top5:
    idx = page[0]
    score = page[1]
    name = num2name[idx]
    print("id : ",idx," ; score : ",score," ; name : ",name)

print("last 5 :")
for page in last5:
    idx = page[0]
    score = page[1]
    name = num2name[idx]
    print("id : ",idx," ; score : ",score," ; name : ",name)


# scatter plots

with open("pagerank_wiki_015.txt") as f :
    pagerank015 = [line.strip() for line in f]
    pagerank015 = [line.split(" ") for line in pagerank015]
    pagerank015 = [float(line[1]) for line in pagerank015]

with open("pagerank_wiki_010.txt") as f :
    pagerank010 = [line.strip() for line in f]
    pagerank010 = [line.split(" ") for line in pagerank010]
    pagerank010 = [float(line[1]) for line in pagerank010]

with open("pagerank_wiki_020.txt") as f :
    pagerank020 = [line.strip() for line in f]
    pagerank020 = [line.split(" ") for line in pagerank020]
    pagerank020 = [float(line[1]) for line in pagerank020]

with open("pagerank_wiki_050.txt") as f :
    pagerank050 = [line.strip() for line in f]
    pagerank050 = [line.split(" ") for line in pagerank050]
    pagerank050 = [float(line[1]) for line in pagerank050]

with open("pagerank_wiki_090.txt") as f :
    pagerank090 = [line.strip() for line in f]
    pagerank090 = [line.split(" ") for line in pagerank090]
    pagerank090 = [float(line[1]) for line in pagerank090]

with open("degreesout_wiki.txt") as f :
    degreesout = [line.strip() for line in f]
    degreesout = [line.split(" ") for line in degreesout]
    degreesout= [float(line[1]) for line in degreesout]

with open("degreesin_wiki.txt") as f :
    degreesin = [line.strip() for line in f]
    degreesin = [line.split(" ") for line in degreesin]
    degreesin= [float(line[1]) for line in degreesin]

import matplotlib.pyplot as plt
from numpy import log

plt.figure()
plt.scatter(log(pagerank015),log(degreesout))
#plt.xlim(0,0.014)
#plt.ylim(0,130000)
plt.xlabel("Pagerank with alpha=0.15")
plt.ylabel("Out-degree")
plt.title("Out-degree vs Pagerank(alpha=0.15)")
plt.savefig("fig2")

plt.figure()
plt.scatter(pagerank015,pagerank090)
plt.xlabel("Pagerank with alpha=0.15")
plt.ylabel("Pagerank with alpha=0.90")
plt.xlim(0,0.014)
#plt.ylim(0,0.012)
plt.title("Pagreank 0.15 vs pagerank 0.90")
plt.savefig("fig6")
