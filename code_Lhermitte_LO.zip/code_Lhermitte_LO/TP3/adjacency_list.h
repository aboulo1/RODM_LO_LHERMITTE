#ifndef ADJACENCY_LIST_H_INCLUDED
#define ADJACENCY_LIST_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <time.h>//to estimate the runing time

#define NLINKS 100000000 //maximum number of edges for memory allocation, will increase if needed

typedef struct {
	unsigned long s;
	unsigned long t;
} edge;

//edge list structure:
typedef struct {
	unsigned long n;
	unsigned long e;
	edge *edges;
	unsigned long *cd;//cumulative degree 
	unsigned long *adj;// adjacency list
} adj_arr;

//compute the maximum of three unsigned long
inline unsigned long max3(unsigned long a,unsigned long b,unsigned long c){
	a=(a>b) ? a : b;
	return (a>c) ? a : c;
};

//reading the edgelist from file
adj_arr* readedgelist(char* input);

//Represent the graph with its adjacency array
void adjacency_array(adj_arr* g);


void free_adj_arr(adj_arr *g);

#endif
