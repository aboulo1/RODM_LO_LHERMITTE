
from random import random

n = 400
p = 0.8
q = 0.01

with open("benchmark.txt","w") as f :
    
    for i in range(n):
        for j in range(n):
            if (i%4==j%4):
                a = random()
                # appartiennent aux même cluster => connectés avec proba p
                if a<p:
                    f.writelines(str(i)+" "+str(j)+"\n")
            else:
                b = random()
                # connectés avec proba q
                if b<q:
                    f.writelines(str(i)+" "+str(j)+"\n")

with open("benchmark.txt") as f:
    graph = [line.strip() for line in f]
    graph = [line.split(" ") for line in graph]
    graph = [[int(line[0]),int(line[1])] for line in graph]

import networkx as nx
G = nx.Graph(graph)

import matplotlib.pyplot as plt
plt.figure()
nx.draw(G)
plt.title("p = "+str(p)+" q = "+str(q)+" p/q = "+str(round(p/q,2)))
plt.savefig("pdivq80")