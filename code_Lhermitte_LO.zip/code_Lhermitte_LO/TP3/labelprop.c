#include <stdlib.h>
#include <stdio.h>
#include <time.h>//to estimate the runing time
#include "adjacency_list.h"

typedef struct {
	unsigned long length;
	unsigned long *labels;
} listoflabels;

// fonction qui renvoie la liste des labels majoritaires
listoflabels* labelsmajoritaires(unsigned long *labels, unsigned long length){

    // compute max_labels
    unsigned long max_labels = 0;
    unsigned long l;
    for(l=0;l<length;l++){
        if(labels[l]>max_labels){max_labels=labels[l];}
    }

    // countdifferentlabels contient le nombre d'occurence de chacun des labels dans labels
    unsigned long countdifferentlabels[max_labels+1];
    for(l=0;l<max_labels+1;l++){countdifferentlabels[l]=0;}
    for(l=0;l<length;l++){countdifferentlabels[labels[l]]++;}


    // compute max_countdifferentlabels
    unsigned long max_countdifferentlabels = 0;
    for(l=0;l<max_labels+1;l++){
        if(countdifferentlabels[l]>max_countdifferentlabels){max_countdifferentlabels=countdifferentlabels[l];}
    }


    // on compte combien de labels sont concernés
    unsigned long nblabelsconcernes = 0;
    for(l=0;l<max_labels+1;l++){
        if(countdifferentlabels[l]==max_countdifferentlabels){nblabelsconcernes++;}
    }


    // on va chercher les labels concernés
    listoflabels *majorlabels = malloc(sizeof(listoflabels));
    majorlabels->labels = malloc(nblabelsconcernes*sizeof(unsigned long));
    majorlabels->length = nblabelsconcernes;
    unsigned long compteur = 0;
    for(l=0;l<max_labels+1;l++){
        if(countdifferentlabels[l]==max_countdifferentlabels){
            majorlabels->labels[compteur] = l;
            compteur++;
        }
    }

    return majorlabels;

}

void free_listoflabels(listoflabels *majorlabels){
    free(majorlabels->labels);
    free(majorlabels);
}


unsigned long* labelprop(adj_arr *g){

    unsigned long *labels = malloc(g->n*sizeof(unsigned long));

    // on commence par assigner un label unique à chaque noeud ; label(noeud) = id
    unsigned long i;
    for(i=0;i<g->n;i++){
        labels[i] = i;
    }

    unsigned long permutation[g->n];
    for(i=0;i<g->n;i++){
        permutation[i] = i;
    }
    // permutation[i] est l'id du noeud situé à la position i de la permutation

    unsigned long hasmajorlabel[g->n];
    for(i=0;i<g->n;i++){
        hasmajorlabel[i]=0;
    }
    unsigned long sum = 0;

    // if sum < g->n => we have to continue
    while(sum<g->n){

        // shuffle (Fisher-Yates)
        
        for(i=g->n-1;i>0;i--){
            // j = random integer such that 0 ≤ j ≤ i
            unsigned long j = rand() %(i+1);
            unsigned long tmp = permutation[i];
            permutation[i] = permutation[j];
            permutation[j] = tmp;
        }

        // on itere sur tous les noeuds du graphe
        // ici c'est pour modifer les labels

        for(i=0;i<g->n;i++){
            // noeud qu'on traite actuellement
            unsigned long node = permutation[i];
            unsigned long actual_label = labels[node];
            // son degre
            unsigned long degree = g->cd[node+1] - g->cd[node];

            // neighbors contient les voisins de node
            unsigned long neighbors[degree];
            unsigned long l;
            for(l=0;l<degree;l++){
                neighbors[l] = g->adj[g->cd[node]+l];
            }

            // neighborlabels contient les labels des voisins de node
            unsigned long neighborlabels[degree];
            for(l=0;l<degree;l++){neighborlabels[l]=labels[neighbors[l]];}

            // voisins majoritaires
            listoflabels *majorlabels = labelsmajoritaires(neighborlabels,degree);

            // on verifie si le label actuel est dans la liste
            unsigned long c = 0;
            for(l=0;l<majorlabels->length;l++){
                if(actual_label==majorlabels->labels[l]){c++;}
            }


            if (c==0){
                // on tire aléatoirement un nombre entre 0 et majorlabels->length - 1
                int random = rand() % (majorlabels->length);
                unsigned long newlabel = majorlabels->labels[random];
                labels[i] = newlabel;
            }

            free_listoflabels(majorlabels);

        }

        // on regarde si il reste des noeuds qui n'ont pas encore le label majoritaire

        // on itère sur les noeuds
        // cette fois on ne fait que verifier s'il reste des labels à changer

        for(i=0;i<g->n;i++){

            // noeud qu'on traite actuellement
            unsigned long node = permutation[i];
            unsigned long actual_label = labels[node];
            // son degre
            unsigned long degree = g->cd[node+1] - g->cd[node];

            // neighbors contient les voisins de node
            unsigned long neighbors[degree];
            unsigned long l;
            for(l=0;l<degree;l++){
                neighbors[l] = g->adj[g->cd[node]+l];
            }

            // neighborlabels contient les labels des voisins de node
            unsigned long neighborlabels[degree];
            for(l=0;l<degree;l++){neighborlabels[l]=labels[neighbors[l]];}

            // voisins majoritires
            listoflabels *majorlabels = labelsmajoritaires(neighborlabels,degree);

            // on verifie si le label actuel est dans la liste
            unsigned long c = 0;
            for(l=0;l<majorlabels->length;l++){
                if(actual_label==majorlabels->labels[l]){c++;}
            }

            if (c==0){
                hasmajorlabel[l] = 0;
            }
            else{hasmajorlabel[l] = 1;}

            free_listoflabels(majorlabels);

        }

        sum=0;
        for(i=0;i<g->n;i++){
            sum += hasmajorlabel[i];
        }
        printf("sum : %lu\n",sum);

    }
    return labels;
}


int main(int argc,char** argv){
	adj_arr* g;
	time_t t1,t2;

	t1=time(NULL);

	printf("Reading edgelist from file %s\n",argv[1]);
	g=readedgelist(argv[1]);

	printf("Number of nodes: %lu\n",g->n);
	printf("Number of edges: %lu\n",g->e);

    printf("Building the adjacency array\n");
	adjacency_array(g);

    printf("testing\n");

    
    printf("Label propagation \n");

    unsigned long *labels = labelprop(g);

    unsigned long i;
    for(i=0;i<g->n;i++){
        printf("%lu ",labels[i]);
    }

    free(labels);

    free_adj_arr(g);

	t2=time(NULL);

	printf("- Overall time = %ldh%ldm%lds\n",(t2-t1)/3600,((t2-t1)%3600)/60,((t2-t1)%60));

	return 0;
}